// config/database.js
module.exports = {
    'connection': {
        'host': 'localhost',
        'user': 'root',
        'password': 'root'
    },
	'database': 'controlcenter',
    'users_table': 'users'
};